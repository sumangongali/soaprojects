There are three types of input , to be tested:
1)CompensateScope
2)Compensate
3)3