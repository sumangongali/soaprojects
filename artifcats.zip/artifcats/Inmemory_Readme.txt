Inputs ::
pass
fail

if these inputs dont work then create /tmp/write folder for file write.